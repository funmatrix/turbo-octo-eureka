class Settings:
    secretKey="321897kdbmgj321djnbug#@4rhxcjk6(!d)"