from flask import Flask, render_template, jsonify
from jinja2 import TemplateNotFound

app = Flask(__name__)


@app.route('/')
def homepage():
    return render_template("home.html")


@app.route('/<string:filename>')
def getUser(filename):
    return render_template("aboutus.html")


@app.route('/number/<string:id>')
def praseNumber(id):
    try:
        x = int(id)
        return str(x), 200
    except Exception as err:
        msg = {"Message": "Some error occured"}
        return str(msg), 500


if __name__ == "__main__":
    app.run()
